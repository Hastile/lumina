# Chat에서 Lumina 편집 실행

2026-10-31 갱신. Chat → GPT Bridge → 로컬 Lumina MCP(stdio) → Lumina GUI 구조의 운영 기준이다. Lumina MCP 자체는 로컬 프로세스이며 Chat에 직접 연결할 원격 HTTP 서버가 아니다. Bridge는 중계·파일 작업을 맡고, GUI 연결·대상 보호·편집 동작은 Lumina가 맡는다. 도구 스키마 전체를 정적 파일로 복제하지 않는다. 호출 시 연결된 도구 정의를 확인한다.

## 연결과 역할

| 목적 | 사용할 연결 | 기준 |
|---|---|---|
| 프로젝트/시퀀스 조회·편집·렌더·저장 | Bridge `lumina_list_tools` / `lumina_call_tool` → Lumina MCP | GUI의 같은 문서에서 작업 |
| 로컬 문서·대본·폴더 검색/읽기 | GPT Bridge | 먼저 `get_workspace_info` |
| 실제 소스 파일 이동 | GPT Bridge `move_file` | 이동 결과 확인 후 Lumina에 가져오기/재연결 |
| 음성 정렬·SRT | 연결된 Phrase Studio 도구 | 실제 도구가 있을 때만 사용 |

2026-10-31 Bridge 재시작 후 `get_workspace_info`로 확인한 루트는 다음과 같다. 작업할 때 다시 조회한다.

| workspace | 로컬 루트 | 용도 |
|---|---|---|
| `default` | `D:\Dev` | 개발 폴더와 편집 지침 |
| `YouTube` | `D:\유튜브 채널` | 영상 프로젝트와 정리된 소스 |
| `Downloads` | `C:\Users\HETX\Downloads` | 일반 다운로드 |
| `Videos` | `C:\Users\HETX\Videos` | 비디오 폴더·OBS 녹화 소스 |
| `YouTubeVideos` | `C:\Users\HETX\Downloads\hitomi_downloader_GUI\hitomi_downloaded_youtube` | 다운로드한 유튜브 영상 |
| `Obsidian` | `D:\Obsidian` | 대본·노트 |
| `flower` | `C:\Users\HETX\flower` | Unity 프로젝트 |

Bridge 파일 인자는 해당 루트의 **상대 경로**, Lumina의 프로젝트 경로는 로컬 **절대 경로**를 사용한다. `YouTube`는 프로젝트 폴더이고 `YouTubeVideos`는 다운로드 소스 폴더이므로 혼동하지 않는다.

예: Bridge `read_file(workspace="default", path="lumina/docs/editing-grammar/README.md")`. YouTube 루트에서 프로젝트를 찾을 때는 `Project/...`부터 탐색한다. 파일명·경로는 실제 목록을 보고 확정한다.

녹화 소스는 `list_directory(workspace="Videos", path="", depth=1)`, 유튜브 다운로드 소스는 `list_directory(workspace="YouTubeVideos", path="", depth=1)`로 탐색한다. 하위 폴더가 있으면 실제 목록에 나온 경로로 좁힌다. 이동을 요청받으면 해당 workspace를 출발지로, `YouTube`의 확인된 프로젝트 하위 폴더를 목적지로 지정한다. 목적지 부모 폴더가 있어야 하며 기존 파일을 덮어쓰지 않는다.

폴더 추가 후 현재 Chat의 도구 정의에 새 workspace가 보이지 않으면 GPT Bridge 연결/도구 목록을 새로고침한 뒤 다시 확인한다. 이름을 임의로 바꾸거나 `..` 경로로 우회하지 않는다.

## 첫 작업

아래의 Lumina 도구명은 Chat에 직접 노출된 함수명이 아니다. 먼저 `lumina_list_tools(name="get_editor_status")`처럼 정확한 이름으로 현재 스키마를 확인하고, `lumina_call_tool(name="get_editor_status", arguments={})`처럼 중계 호출한다. 다른 Lumina 도구도 동일하다. 파일 도구는 Bridge에 직접 호출한다.

1. `get_editor_status()`로 GUI 상태만 조회한다.
2. 사용자가 지정한 실제 `.lumina` 경로로 `ensure_editor(project_path=...)`를 호출한다. GUI가 없으면 실행하고, 열린 대상이면 미저장 상태를 유지하며 활성화한다.
3. `list_projects()`와 `get_project()`로 경로·활성 프로젝트·시퀀스 목록을 확인한다.
4. 대상 시퀀스를 `sequence_set_active`로 열고, 명시한 ID로 `get_timeline_state`를 읽는다. 필요한 클립 속성은 `get_clips`로 확인한다.
5. 컷 계획 → 소스 확인 → 작은 편집 단위 → 결과 재조회 → 합성 프레임 검수 → 저장 순으로 진행한다.

예: `ensure_editor`의 현재 정의를 확인한 뒤 `lumina_call_tool(name="ensure_editor", arguments={"project_path":"<실제 절대 경로>"})`로 준비한다. 이미 열린 프로젝트를 매번 `open_project`로 다시 열지 않는다.

프로젝트 이름만 같다는 이유로 대상을 확정하지 않는다. 현재 활성 탭이 사용자가 요청한 프로젝트라는 보장도 없다. 새 프로젝트가 필요한 경우에만 `new_project`를 사용한다.

## 편집과 오류 복구

- `begin_transaction(label=...)` 후 관련 변경을 수행한다. 확인된 실패이고 현재 열린 transaction이 자신의 작업이면 `rollback_transaction`, 성공이면 `commit_transaction`한다. 끊김으로 transaction 상태가 불명확하면 먼저 재조회한다. 다른 사람의 작업을 임의로 undo하지 않는다.
- `clip_place`/`clip_move` 반환의 `covered`를 확인한다. 정지 이미지의 기본 길이, 효과음 꼬리, 한 프레임 초과로 이웃 클립이 지워질 수 있다.
- `TARGET_CHANGED`는 잘못된 프로젝트에 계속 쓰지 말라는 신호다. `ensure_editor`로 요청 대상을 재확인하고 타임라인을 다시 읽는다.
- 시간 초과는 미실행의 증거가 아니다. 중복 배치·중복 import·중복 export를 피하도록 현재 클립/미디어/작업 목록을 확인한다.
- GUI 연결 실패를 `.lumina` 직접 수정이나 헤드리스로 우회하지 않는다. 도구가 없는 기능은 누락 기능과 필요한 입력을 보고한다.
- 파일 이동은 Bridge `move_file`의 결과를 확인한다. 기존 등록 미디어라면 현재 미디어 ID를 조회해 `media_relink` → 경로 검증 → `save_project`한다. 경로 오류를 고치려고 장면을 삭제하거나 다른 소스로 바꾸지 않는다.

## 자막·음성 준비

### Lumina 내부 음성 기능 우선 사용

새 텍스트 패널은 대본·캡션·그래픽을 구분하고 모든 자막 트랙을 표시한다. Chat도 같은 엔진을 Bridge `lumina_call_tool`로 호출한다. 현재 도구 정의에서 아래 도구가 제공되는지 먼저 확인한다. 구형 실행 중인 앱은 업데이트 후 다시 연결해야 한다.

1. `speech_status`로 런타임을 확인하고 대상 시퀀스 및 실제 내레이션 오디오 트랙 ID를 읽는다.
2. `speech_start(sequence_id=..., audio_track_id=..., mode="retime", caption_track_ids=[...])`로 최신 자막의 문구·분할·ID를 유지하며 음성 정렬한다. 새 받아쓰기는 `mode="transcribe"`, 작성한 대본 정렬은 `mode="script"`다. 롱폼은 `shorts=false`다.
3. 반환된 job ID로 `speech_job`을 조회한다. `preview`는 분석 완료이며 아직 편집하지 않은 상태다. 결과의 문구·ID·경계·겹침을 검수하고 주요 지점을 재생해 확인한다. 글자 수 비례 배분을 음성 정렬로 대체하지 않는다.
4. 검수한 작업은 `speech_apply(job_id=...)`로 한 번에 적용한다. Undo 가능하며 분석 이후 타임라인이 달라졌으면 적용을 거부한다. 상태를 다시 읽고 필요하면 재분석한다. 대상 프로젝트를 확인하고 저장한다.
5. 자막 분할은 `caption_split_text`를 사용한다. 현재 문구를 `expected_text`로 넣고 `offset`은 Unicode 문자 기준이다. 저장된 음성 정렬 정보가 없으면 실제 확인한 `at` 시각을 명시한다. 커서 앞뒤 문구와 타임라인 경계를 동시에 분할한다. 마침표·띄어쓰기·줄바꿈 수정은 음성 정렬 정보를 유지한다. `caption_merge_next(direction="previous")`는 이전 자막과 병합한다.

대본 정렬과 기존 자막 재정렬은 자막 끝을 다음 자막 시작에 연결해 중간 빈 구간을 없앤다. 첫 발화 전·마지막 발화 후까지 자막을 늘리지는 않는다. GUI는 Enter 분할, Shift+Enter 강제 줄바꿈, 맨 앞 Backspace 병합을 지원하며 문구 수정은 자동 반영된다. 프로젝트 파일 저장은 별도다.

내부 기능은 선택한 내레이션 트랙의 컷·속도·배치를 반영해 분석하며 Phrase 서버를 사용하지 않는다. 자세한 설치·운영 설명은 `D:\Dev\lumina\docs\text-panel.md`다. 아래 외부 Phrase 절차는 내부 도구가 없는 구버전의 대체 경로다.

### Lumina에서 수정한 자막을 음성 기준으로 재정렬

`preserve_segments=true`는 **Phrase에 저장된 자막**을 보존한다. Lumina의 최신 문구·분할을 자동으로 읽지 않는다. 최신 수정본을 옛 Phrase 프로젝트로 덮지 않는다. 아래 단계의 Phrase 호출은 모두 Bridge `phrase_studio`를 사용한다.

1. Lumina MCP로 대상 프로젝트·시퀀스와 실제 자막 트랙을 읽는다. 최신 자막의 clip/cue ID, 정확한 문구, 순서, 시작/끝을 확보한다. 사용자 지정 분할과 마침표 제거 등 문구 수정을 그대로 보존한다. 개수를 하드코딩하지 않는다.
2. 내레이션의 실제 미디어 경로와 타임라인 배치를 확인한다. Phrase에 넘길 음성과 자막의 시간축이 같아야 한다. 단일 1배속 클립이면 `음성 시간 = 시퀀스 시간 - 클립 배치 시작 + source_in`으로 변환한다. 잘라 붙인 음성·여러 클립·속도 변경이면 검증된 매핑을 만들거나 내레이션만 동일 시간축으로 출력한 파일을 사용한다. BGM이 섞인 전체 영상이나 다른 테이크를 임의로 쓰지 않는다. 길이가 같다는 사실만으로 동일 음성이라고 판정하지 않는다.
3. Bridge `write_file`로 작업용 JSON을 새 파일에 저장한다. 형식은 아래와 같다. `audio_duration`은 해당 음성 파일의 실제 길이(초), `start/end`는 음성 파일 기준 초다. ID는 Lumina 자막 ID를 사용해 나중에 대응시킨다. 예시 숫자는 실제 작업에 복사하지 않는다.

```json
{"audio_duration":2.0,"segments":[
  {"id":"<첫 자막 ID>","start":0.0,"end":1.0,"text":"시작되자"},
  {"id":"<다음 자막 ID>","start":1.0,"end":2.0,"text":"일본에서는"}
]}
```

4. `phrase_studio(action="prepare_retime", workspace="YouTube", path="<실제 음성 상대 경로>", segments_path="<JSON 상대 경로>")`를 호출한다. 두 경로는 같은 workspace 기준이다. 이는 음성을 **새 Phrase 프로젝트**로 가져오고 최신 자막을 저장한다. 기존 Phrase 프로젝트와 Lumina는 수정하지 않는다. 반환된 `project_id`와 자막 수를 기록하고 `prepared_not_aligned`임을 확인한다. 아직 정렬된 결과가 아니다. Phrase는 첫/마지막 경계와 자막 사이 빈 구간을 음성 길이에 맞춰 정규화하므로 입력 시간의 그대로 보존은 보장하지 않는다.
5. 새 ID로 `analyze(project_id=..., preserve_segments=true, precise=true, language="ko", shorts=false)`를 호출한다. `shorts=false`는 롱폼 기준이다. `job`으로 완료를 확인한다. 글자 수 비례로 시간을 나누거나 기존 시간값을 음성 정렬 결과라고 보고하지 않는다.
6. `timing_preview`를 페이지별로 전부 읽어 자막 수·ID·문구·순서가 최신 수정본과 같은지, 시간이 음성 범위 안에서 단조롭게 이어지는지 확인한다. 큰 이동·짧은 자막·발화와 다른 문구를 검토한다. `precise=true`는 음향 정렬을 요청하는 것이며 프레임 정확도를 보장하지 않는다. 직접 청취 여부도 별도로 기록한다.
7. 미리보기가 유효하면 `apply_timing`하고 `export_srt`로 새 이름에 출력한다. 내보내기에는 완료된 `job_id`를 함께 전달한다. 오디오 정렬 결과와 원래 타임라인 시간축을 변환한 뒤 Lumina에 반영한다.
8. **기존 자막의 텍스트·스타일·트랙을 유지하며 시간만 수정하는 방법을 우선한다.** 현재 MCP의 실제 편집 도구 정의를 확인한다. ID로 대응시키고 transaction 안에서 변경한 뒤 개수·문구·겹침·경계와 합성 화면을 재검수한다. SRT 일괄 가져오기로 중복 자막을 만들거나 기존 효과를 지우지 않는다. 사용자가 반영·저장을 요청한 범위에서만 저장한다.

이 경로는 새 Phrase 프로젝트를 만들므로 import/prepare/analyze가 시간 초과되면 무조건 반복하지 않는다. 도구가 반환한 새 프로젝트 ID나 projects/job 조회로 완료 여부를 먼저 확인한다. 준비 중 실패하면 생성된 프로젝트 ID를 오류에 포함한다. `prepare_retime` 또는 `segments_path`가 Chat 도구 정의에 없으면 GPT Bridge 연결을 새로고침해야 한다.

Phrase Studio가 실제 연결되어 있으면 health/projects 확인 후 대상 오디오와 대본을 지정한다. 가져오기·분석은 변경 작업이다. 불확실한 시간 초과 후 새 작업을 중복 생성하지 말고 project/job 상태를 확인한다. `preserve_segments`를 썼다면 timing preview를 확인하고 적용한 뒤 SRT를 내보낸다. 글자 수 비례로 타임스탬프를 만들지 않는다. SRT 생성은 Lumina에 반영된 상태와 다르므로 별도로 import하고 검수한다.

기존 음성 처리 기준은 Hard Limiter ceiling -4 dB, boost 0, look-ahead 7 ms, release 100 ms다. 임의 EQ/loudnorm을 추가하지 않는다. 이 수치를 구현하는 도구가 현재 없으면 미처리 상태로 남긴다. 과거 ffmpeg 근사식·개발 CLI를 Chat에서 실행할 수 있다고 가정하지 않는다.

## 검수 기록

| 항목 | 기록할 내용 |
|---|---|
| 대상 | 프로젝트 절대 경로, 시퀀스명/ID, fps |
| 변경 | 구간, 목적, 실제 반영 내용 |
| 화면 근거 | 원본 완성 출력 / Lumina 합성 / 소스 프레임 / 타임라인 |
| 수행한 검수 | 정지 프레임 / 연속 재생 / 직접 청취 / 음량 측정을 각각 표시 |
| 남은 문제 | 없는 소스, 미지원 효과, 오프라인, 미검수 구간 |
| 저장/출력 | 저장 성공, 출력 작업 상태, 결과 파일 경로 |

`export_media` 요청 성공은 완료가 아니다. 반환된 작업 상태와 필요 시 `list_jobs`로 완료·실패를 확인한다. 출력 검증 성공과 직접 시청·청취는 별개다.

## 과거 문서와 충돌할 때

- `lumina_call_tool`이 Chat의 기본 실행 경로다. `lumina_live_status`는 Bridge의 보조 상태 도구이며 GUI 가시성이나 전체 MCP 정상 동작의 증거로 삼지 않는다. 정상 경로는 중계된 `get_editor_status`와 `ensure_editor`다.
- `clip.place`, `shorts.set_copy` 같은 과거 표기는 개념·내부 명령명일 수 있다. 현재 MCP의 `clip_place`, `shorts_set_copy` 등 실제 도구를 검색한다.
- CLI, Python, ffmpeg, 로컬 개인 메모리 읽기는 Chat에서 자동 제공되는 기능이 아니다. 필요한 자료는 Bridge 또는 업로드된 파일로 읽는다.
- 공통 문법의 의미 중심 컷 판단이 예전 빈도 통계보다 우선한다. 쇼츠의 사용자 확정 최소 길이·마커 조건은 보존하되, ‘항상 두 자막마다 컷’, ‘4초를 넘으면 무조건 컷’으로 바꾸지 않는다.
- 업로드된 참고 기록의 시퀀스 ID·미디어 개수·미완료 목록은 과거 스냅샷이다. 현재 프로젝트 상태로 취급하지 않는다.

## 문서 원본

저장소 기준 `docs/editing-grammar/README.md`, `docs/editing-grammar/lumina-workflow.md`, `docs/mcp-lifecycle.md`, `docs/shorts-editing/README.md`를 사용한다. 현재 도구 정의와 구현 확인 위치는 `engine/lumina/mcp_server.py`, `engine/lumina/client.py`다. 코드 전체는 Chat 프로젝트에 상시 업로드할 필요가 없다.

## 연결 장애 기록과 재검증

2026-10-31: 도구 검색에는 `get_editor_status`가 있었으나 호출은 `UNKNOWN_METHOD: editor.status`로 실패했다. 원인은 Bridge 설정의 `lumina.liveOnly=true`가 실행한 구형 `LiveEngine`이다. 이 계층은 Lumina의 `GuiEngine`을 거치지 않고 내부 메서드를 GUI 엔진으로 직접 전달했다. `ensure_editor`와 대상 보호 역시 같은 계층을 필요로 하므로 상태 조회만 임시 대체하지 않는다.

Bridge 사용자 설정을 백업하고 `liveOnly=false`, 실행 인자를 `uv run --project D:\Dev\lumina\engine python -m lumina mcp`로 바꿨다. 이는 헤드리스 편집을 켠 것이 아니다. 현재 Lumina의 기본은 `GuiEngine`이며 `LUMINA_HEADLESS=1`을 설정하지 않는다. Bridge를 재시작한 후 중계된 `get_editor_status`가 `mode=gui`, `connected=true`, `headless=false`를 반환했고 프로젝트 개요 조회도 성공했다.

연결 결과는 도구 검색 성공 / GUI 엔진 연결 / 프로젝트 읽기 / 합성 이미지 반환 / 편집 / 저장·내보내기를 분리해 기록한다. GUI 엔진 연결은 창이 현재 화면에 보이거나 가려지지 않았다는 보장이 아니다. `visibleWindow=not_checked`는 미확인이며 그 자체가 연결 실패는 아니다. 사용자 프로젝트를 시험 삼아 변경하지 않는다. 쓰기 테스트가 필요하면 별도 테스트 프로젝트로 범위를 명시한다.
